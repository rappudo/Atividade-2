
public class No {

    //Atributos
    private Tarefa dado; //Informação
    private No proximoNo, anteriorNo; //Ponteiros

    //Construtor
    public No(Tarefa dado){
        this.dado = dado;
        this.proximoNo = proximoNo;
        this.anteriorNo = anteriorNo;

    }

    //Gets e sets
    public Tarefa getDado() {
        return dado;
    }

    public void setDado(Tarefa dado) {
        this.dado = dado;
    }

    public No getProximoNo() {
        return proximoNo;
    }

    public void setProximoNo(No proximoNo) {
        this.proximoNo = proximoNo;
    }

    public No getAnteriorNo() {
        return anteriorNo;
    }

    public void setAnteriorNo(No anteriorNo) {
        this.anteriorNo = anteriorNo;
    }

}
