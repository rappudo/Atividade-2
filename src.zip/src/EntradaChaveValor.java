
public class EntradaChaveValor {

    private int chave;
    private Membro Valor;

    public EntradaChaveValor(int chave, Membro Valor) {
        this.chave = chave;
        this.Valor = Valor;
    }

    public int getChave() {
        return chave;
    }

    public Membro getValor() {
        return Valor;
    }

    public void setValor(Membro Valor) {
        this.Valor = Valor;
    }

    public String toString() {
        return "{" + chave + " = " + Valor + "}";
    }
}
