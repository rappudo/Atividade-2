
public class NoArvore {

    private Tarefa valor;
    private NoArvore esquerdo, direito;
    // Altura inicializada como 0 para representar uma folha
    private int altura;
    public NoArvore(Tarefa valor) {
        this.valor = valor;
        this.altura = 0; // Altura de uma folha é 0
    }

    //Gets e sets
    public Tarefa getValor() {
        return valor;
    }

    public void setValor(Tarefa valor) {
        this.valor = valor;
    }

    public NoArvore getEsquerdo() {
        return esquerdo;
    }

    public void setEsquerdo(NoArvore esquerdo) {
        this.esquerdo = esquerdo;
    }

    public NoArvore getDireito() {
        return direito;
    }

    public void setDireito(NoArvore direito) {
        this.direito = direito;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
}
