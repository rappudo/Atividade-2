import java.util.ArrayList;

public class Membro {

    private int id;
    private String nome, cargo;
    private ArrayList<Tarefa> tarefas;

    public Membro(int id, String nome, String cargo){
        this.id = id;
        this.nome = nome;
        this.cargo = cargo;
        this.tarefas = new ArrayList<Tarefa>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void adcionarTarefa(Tarefa tarefa){
        tarefas.add(tarefa);
    }
}
