import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        ListaDuplamenteEncadeada lde = new ListaDuplamenteEncadeada();
        TabelaHash_EncadeamentoSeparado thes = new TabelaHash_EncadeamentoSeparado(10);
        AVL avl = new AVL();

        System.out.println("id");
        int idM = input.nextInt();
        input.nextLine();
        System.out.println("nome");
        String nomeM = input.nextLine();
        System.out.println("cargo");
        String cargo = input.nextLine();

        Membro membro = new Membro(idM, nomeM, cargo);
        if(thes.buscar(idM) == null) {
            thes.adcionar(idM, membro);
        }

        while(true){
            System.out.println("Menu:\n1-Adcionar tarefa;\n2-Excluir Tarefa;\n3-Atribuir tarefa a um membro;\n" +
                    "4-");
            int menu = input.nextInt();
            switch (menu){
                case 1:
                    System.out.println("Insira o id da tarefa: ");
                    int idT = input.nextInt();
                    input.nextLine();
                    System.out.println("Insira o nome da tarefa: ");
                    String nomeT = input.nextLine();
                    System.out.println("Insira a descrição da tarefa: ");
                    String descricaoT = input.nextLine();
                    System.out.println("Insira o status atual da tarefa: ");
                    String status = input.nextLine();
                    System.out.println("Insira o valor da prioridade da tarefa: ");
                    int prioridade = input.nextInt();
                    input.nextLine();

                    Tarefa tarefa = new Tarefa(idT, nomeT, descricaoT, status, prioridade);
                    lde.inserirNoInicio(tarefa);
                    avl.inserir(tarefa);
                    break;
                case 2:
                    System.out.println("Insira o id da tarefa a ser excluida: ");
                    int idRemov = input.nextInt();
                    input.nextLine();
                    avl.remover(lde.buscar(idRemov));
                    lde.removerNo(idRemov);
                    break;
                case 3:
                    System.out.println("Insira o id do membro que recebera a tarefa: ");
                    int idAtrib = input.nextInt();
                    input.nextLine();
                    System.out.println("Insira o id da tarefa que se deseja adcionar: ");
                    int idTarefa = input.nextInt();
                    input.nextLine();
                    thes.buscar(idAtrib).adcionarTarefa(lde.buscar(idTarefa));
                    break;
                case 4:
                    System.out.println("Insira o id do membro que deseja buscar: ");
                    int idMembro = input.nextInt();
                    System.out.println(thes.buscar(idMembro).toString());
                    break;
                case 5:
                    
            }
        }
    }

}
