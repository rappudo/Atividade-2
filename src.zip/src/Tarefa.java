public class Tarefa {

    private int id, prioridade;
    private String nome, descricao, status;

    public Tarefa(int id, String nome, String descricao, String status, int prioridade){
        if(prioridade > 5 | prioridade < 1){
            System.out.println("Prioridade Inválida!");
        }
        else{
            this.id = id;
            this.nome = nome;
            this.descricao = descricao;
            this.status = status;
            this.prioridade = prioridade;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(int prioridade) {
        this.prioridade = prioridade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
