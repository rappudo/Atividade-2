
public class AVL {
    private NoArvore raiz;

    public AVL() {
        this.raiz = null;
    }

    public int altura(NoArvore no) {
        if (no == null) {
            return -1;
        }
        return no.getAltura();
    }

    public int fatorDeBalanceamento(NoArvore no) {
        if (no == null) {
            return 0;
        }
        return altura(no.getEsquerdo()) - altura(no.getDireito());
    }

    public NoArvore rotacaoDireita(NoArvore y) {
        NoArvore x = y.getEsquerdo();
        NoArvore t2 = x.getDireito();

        x.setDireito(y);
        y.setEsquerdo(t2);

        y.setAltura(Math.max(altura(y.getEsquerdo()), altura(y.getDireito())) + 1);
        x.setAltura(Math.max(altura(x.getEsquerdo()), altura(x.getDireito())) + 1);

        return x;
    }

    public NoArvore rotacaoEsquerda(NoArvore x) {
        NoArvore y = x.getEsquerdo();
        NoArvore t2 = y.getEsquerdo();

        y.setEsquerdo(x);
        x.setDireito(t2);

        x.setAltura(Math.max(altura(x.getEsquerdo()), altura(x.getDireito())) + 1);
        y.setAltura(Math.max(altura(y.getEsquerdo()), altura(y.getDireito())) + 1);

        return y;
    }

    public void inserir(Tarefa valor) {
        raiz = inserirRecursivo(raiz, valor);
    }

    public NoArvore inserirRecursivo(NoArvore no, Tarefa valor) {
        if (no == null) {
            return new NoArvore(valor);
        }
        if (valor.getPrioridade() < no.getValor().getPrioridade()) {
            no.setEsquerdo(inserirRecursivo(no.getEsquerdo(), valor));
        } else {
            if (valor.getPrioridade() >= no.getValor().getPrioridade()) {
                no.setDireito(inserirRecursivo(no.getDireito(), valor));
            } else {
                return no;
            }
        }
        no.setAltura(Math.max(altura(no.getEsquerdo()), altura(no.getDireito())) + 1);

        int fatorDeBalanceamento = fatorDeBalanceamento(no);
        if (fatorDeBalanceamento > 1 && valor.getPrioridade() < no.getEsquerdo().getValor().getPrioridade()) {
            return rotacaoDireita(no);
        }
        if (fatorDeBalanceamento < -1 && valor.getPrioridade() > no.getDireito().getValor().getPrioridade()) {
            return rotacaoEsquerda(no);
        }
        if (fatorDeBalanceamento > 1 && valor.getPrioridade() > no.getEsquerdo().getValor().getPrioridade()) {
            no.setEsquerdo(rotacaoEsquerda(no.getEsquerdo()));
            return rotacaoDireita(no);
        }
        if (fatorDeBalanceamento < -1 && valor.getPrioridade() < no.getDireito().getValor().getPrioridade()) {
            no.setDireito(rotacaoDireita(no.getDireito()));
            return rotacaoEsquerda(no);
        }
        return no;
    }

    public Tarefa encontrarMenorValor(NoArvore no) {
        while (no.getEsquerdo() != null) {
            no = no.getEsquerdo();
        }
        return no.getValor();
    }

    public void remover(Tarefa valor) {
        raiz = removerRecursivo(raiz, valor);
    }

    public NoArvore removerRecursivo(NoArvore no, Tarefa valor) {
        if (no == null) {
            return no;
        }
        if (valor.getPrioridade() < no.getValor().getPrioridade()) {
            no.setEsquerdo(removerRecursivo(no.getEsquerdo(), valor));
        } else {
            if (valor.getPrioridade() >= no.getValor().getPrioridade()) {
                no.setDireito(removerRecursivo(no.getDireito(), valor));
            } else {
                if (no.getEsquerdo() == null | no.getDireito() == null) {
                    NoArvore temp = null;
                    if (no.getEsquerdo() != null) {
                        temp = no.getEsquerdo();
                    } else {
                        temp = no.getDireito();
                    }
                    if (temp == null) {
                        temp = no;
                        no = null;
                    } else {
                        no = temp;
                    }
                } else {
                    Tarefa temp = encontrarMenorValor(no.getDireito());
                    no.setValor(temp);
                    no.setDireito(removerRecursivo(no.getDireito(), temp));
                }
            }
        }

        if (no == null) {
            return no;
        }
        no.setAltura(Math.max(altura(no.getEsquerdo()), altura(no.getDireito())) + 1);
        int balance = fatorDeBalanceamento(no);
        if (balance > 1 && fatorDeBalanceamento(no.getEsquerdo()) >= 0) {
            return rotacaoDireita(no);
        }
        if (balance > 1 && fatorDeBalanceamento(no.getEsquerdo()) < 0) {
            no.setEsquerdo(rotacaoEsquerda(no.getEsquerdo()));
            return rotacaoDireita(no);
        }
        if (balance < -1 && fatorDeBalanceamento(no.getDireito()) <= 0) {
            return rotacaoEsquerda(no);
        }
        if(balance < -1 && fatorDeBalanceamento(no.getDireito()) > 0){
            no.setDireito(rotacaoDireita(no.getDireito()));
            return rotacaoEsquerda(no);
        }
        return no;
    }
}


